/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,php}'],
  theme: {
    extend: {
      backgroundImage: {
        'full-bg': "url('./img/bg.jpg')",
        'reg-bg': "url('./img/bg-reg.png')",
        'fire': 'linear-gradient(to right, rgba(255, 0, 0, 0.35), rgba(255, 127, 0, 0.35))', // Red to Orange
        'water': 'linear-gradient(to right, rgba(0, 0, 255, 0.35), rgba(135, 206, 235, 0.35))', // Blue to Light Blue
        'ghostpkm': "url('./img/creators/ghost-bg.jpg')",
      },
      animation: {
        'slow-spin': 'spin 30s linear infinite', // Custom slow spin animation
        'medium-spin': 'spin 15s linear infinite', // Custom slow spin animation
      },


    },
  },
  plugins: [
  ]
}
