<?php
session_start();
$host = "localhost";
$port = "5432";
$dbname = "pokedexbd";
$user = "postgres";
$password = "root";
$connection_string = "host={$host} port={$port} dbname={$dbname} user={$user} password={$password} ";
$dbconn = pg_connect($connection_string);

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id']; // Get the primary key from the request

    // Assuming you're deleting from a specific table, you'll need to define which table to delete from
    $table = 'YourTableName'; // Replace with the appropriate table name

    // Perform the deletion
    $deleteQuery = "DELETE FROM $table WHERE your_primary_key_column = $id"; // Replace with your primary key column name
    $result = pg_query($dbconn, $deleteQuery);

    if ($result) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => pg_last_error($dbconn)]);
    }
}
?>
