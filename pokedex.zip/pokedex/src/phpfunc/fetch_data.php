<?php include 'db.php';

if (isset($_GET['table'])) {
    $table = $_GET['table'];

    // Step 1: Retrieve the primary key column for the table
    $primaryKeyQuery = "SELECT a.attname as column_name
                        FROM   pg_index i
                        JOIN   pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
                        WHERE  i.indrelid = '{$table}'::regclass AND i.indisprimary;";

    $primaryKeyResult = pg_query($dbconn, $primaryKeyQuery);

    // Check if the query executed successfully
    if (!$primaryKeyResult) {
        echo "Error: Could not retrieve primary key for table $table. " . pg_last_error($dbconn);
        exit();
    }

    // Fetch the primary key column name
    $primaryKeyRow = pg_fetch_assoc($primaryKeyResult);
    $primaryKeyColumn = $primaryKeyRow['column_name'];

    // Step 2: Fetch the column names for the selected table
    $columnNamesQuery = "SELECT column_name FROM information_schema.columns WHERE table_name = '{$table}'";
    $columnNamesResult = pg_query($dbconn, $columnNamesQuery);

    // Check if the column names query executed successfully
    if (!$columnNamesResult) {
        echo "Error: Could not retrieve column names for table $table. " . pg_last_error($dbconn);
        exit();
    }

    // Step 3: Fetch rows for the selected table
    $result = pg_query($dbconn, "SELECT * FROM $table");

    // Check if the query executed successfully
    if (!$result) {
        echo "Error: Could not execute query for table $table. " . pg_last_error($dbconn);
        exit();
    }

    // Display table structure with column names and data
    if (pg_num_rows($result) > 0) {
        echo '<table class="min-w-full table-auto">';
        echo '<thead><tr>';

        // Display the column names
        while ($column = pg_fetch_assoc($columnNamesResult)) {
            echo "<th class='px-4 py-2'>{$column['column_name']}</th>";
        }

        // Add an extra column for actions (edit, delete)
        echo '</tr></thead>';
        echo '<tbody>';

        // Display the table rows
        while ($row = pg_fetch_assoc($result)) {
            echo '<tr>';
            foreach ($row as $value) {
                echo "<td class='border px-4 py-2'>{$value}</td>";
            }

            // Use the dynamic primary key column to refer to the specific row
            echo '<td class="border px-4 py-2 flex gap-2">
                    <button onclick="editRow('.json_encode($row).')" class="bg-emerald-500 text-white px-2 py-1 rounded-full hover:scale-105">Editar</button>
                    <button onclick="showDeleteModal('.$row[$primaryKeyColumn].')" class="bg-red-500 text-white px-2 py-1 rounded">Deletar</button>
                  </td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    } else {
        echo "<p>Ops! Não há nada cadastrado aqui ainda.</p>";
    }
}
?>
