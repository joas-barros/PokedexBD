<?php
session_start();
$host = "localhost";
$port = "5432";
$dbname = "pokedexbd";
$user = "postgres";
$password = "root";
$connection_string = "host={$host} port={$port} dbname={$dbname} user={$user} password={$password} ";
$dbconn = pg_connect($connection_string);
?>