<?php
include './phpfunc/db.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>
    <link rel="stylesheet" href="output.css">
    <link rel="stylesheet" href="input.css">
    <link rel="icon" href="img/pb-icon.svg">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
</head>
<body class="flex flex-col min-h-screen w-screen bg-white max-w-full">
<header class="w-full h-14 flex flex-row items-center justify-between px-10 py-3 border-b border-gray-300">
    <a href="dashboard.php" class="group">
        <img src="img/pokemon.svg" class="w-24 group-hover:scale-110 transition-all ease-in-out">
    </a>

    <div class="w-auto flex gap-10 items-center">
        <a href="#" class="hover:text-white font-medium transition-all ease-in-out border-2 border-red-500 hover:bg-red-500 rounded-full py-1 px-3 bg-gradient-to-tl from-transparent to-transparent hover:from-rose-400 hover:to-red-500 hover:scale-110">Administrador</a>
        <a href="dashboard.php" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Pokedex Completa</a>
        <a href="#" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Sobre nós</a>
        <a href="index.php" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Sair</a>
    </div>
</header>
<main class="flex flex-col justify-center items-center mt-[-30px] p-10 space-x-4 mb-auto">
    <div>
        <div class="flex flex-row flex-wrap gap-5 bg-gray-100 justify-start p-5 rounded-2xl">
            <?php
            // Array of tables to display
            $tables = ['Treinador', 'Pokemon', 'Pokedex', 'Habilidade_Passiva', 'Efeito', 'Tipo', 'Fraquezas', 'Evolucao'];
            foreach ($tables as $table) {
                // Get count of rows in each table
                $result = pg_query($dbconn, "SELECT COUNT(*) FROM $table");
                $count = pg_fetch_result($result, 0, 0);
                ?>
                <section onclick="openModal('<?php echo $table; ?>')" class="bg-white w-56 rounded-xl flex max-w-52 flex-grow flex-row overflow-hidden hover:scale-[1.02] transition-all ease-in-out cursor-pointer">
                    <div class="w-2 h-full bg-red-500"></div>
                    <div class="flex-1 p-3 flex flex-col text-center">
                        <h1 class="text-gray-500 font-bold"><?php echo $table; ?></h1>
                        <div class="p-5"><?php echo $count; ?></div>
                    </div>
                </section>
            <?php } ?>
        </div>

        <!-- Modal -->
        <div id="modal" class="hidden fixed inset-0 bg-black/25 backdrop-blur flex items-center justify-center">
            <div class="bg-white rounded-lg shadow-lg p-5">
                <h2 id="modal-title" class="text-xl font-semibold mb-4"></h2>
                <div id="modal-content"></div>
                <button onclick="closeModal()" class="mt-3 bg-red-500 text-white px-4 py-2 rounded">Fechar</button>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" tabindex="-1" aria-hidden="true" class="fixed inset-0 z-50 flex justify-center items-center hidden bg-black/25 backdrop-blur">
        <div class="relative p-4 w-full max-w-md h-full md:h-auto">
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <div class="p-6 text-center">
                    <h3 class="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">Tem certeza que deseja deletar este registro?</h3>
                    <button id="confirmDeleteBtn" type="button" class="text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2">
                        Sim, deletar
                    </button>
                    <button id="cancelDeleteBtn" type="button" onclick="closeDeleteModal()" class="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">
                        Não, cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

</main>

<footer class="shadow absolute inset-x-0 bottom-0 text-center p-3 bg-gradient-to-t from-slate-950 to-transparent text-white opacity-75">
    © Ciência da Computação - UFERSA 2024.1 | PokedexBD | Todos os direitos reservados.
</footer>

<script>
    let deleteId = null; // Store the ID of the record to be deleted

    function openModal(table) {
        document.getElementById('modal-title').innerText = table;
        fetchTableData(table);
        document.getElementById('modal').classList.remove('hidden');
    }

    function closeModal() {
        document.getElementById('modal').classList.add('hidden');
    }

    async function fetchTableData(table) {
        const response = await fetch(`./phpfunc/fetch_data.php?table=${table}`);
        const data = await response.text();
        document.getElementById('modal-content').innerHTML = data;

        // Add delete buttons event listeners
        const deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                deleteId = this.dataset.id; // Get the ID of the record to be deleted
                document.getElementById('deleteModal').classList.remove('hidden');
            });
        });
    }

    document.getElementById('cancelDeleteBtn').addEventListener('click', () => {
        document.getElementById('deleteModal').classList.add('hidden');
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
<script src="./js/delete.js"></script>

</body>
</html>
