let rowToDelete = null;
let tableToDeleteFrom = null;

function showDeleteModal(id, table) {
    rowToDelete = id;
    tableToDeleteFrom = table;
    const deleteModal = document.getElementById('deleteModal');
    deleteModal.classList.remove('hidden');
}

document.getElementById('cancelDeleteBtn').addEventListener('click', function() {
    const deleteModal = document.getElementById('deleteModal');
    deleteModal.classList.add('hidden');
});

document.getElementById('confirmDeleteBtn').addEventListener('click', function() {

});
