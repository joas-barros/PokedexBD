<?php
session_start();
$host = "localhost";
$port = "5432";
$dbname = "pokedexbd";
$user = "postgres";
$password = "root";
$connection_string = "host={$host} port={$port} dbname={$dbname} user={$user} password={$password}";
$dbconn = pg_connect($connection_string);

if (!$dbconn) {
    die("Error: Unable to connect to the database.");
}

$sql = "SELECT 
        pd.pokedex_num, 
        pd.pokedex_nome, 
        pd.pokedex_tipo_1, 
        pd.pokedex_tipo_2, 
        t1.tipo_nome AS type1_name, 
        t2.tipo_nome AS type2_name,
        pd.pokedex_info,
        pd.pokedex_capturado,
        pd.pokedex_geracao,
        pd.pokedex_taxa_captura
    FROM 
        pokedex pd
    LEFT JOIN 
        tipo t1 ON pd.pokedex_tipo_1 = t1.tipo_id
    LEFT JOIN 
        tipo t2 ON pd.pokedex_tipo_2 = t2.tipo_id"; // Adjust based on your table structure
$result = pg_query($dbconn, $sql);

if (!$result) {
    die("Error in query execution.");
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PokedexBD</title>
    <link rel="stylesheet" href="./output.css">
    <link rel="stylesheet" href="./input.css">
    <link rel="icon" href="img/pb-icon.svg">

</head>
<body class="flex flex-col min-h-screen w-screen bg-white max-w-full">
        <header class="w-full h-14 flex flex-row items-center justify-between  px-10 py-3 border-b border-gray-300">
            <a href="dashboard.php" class="group">
                <img src="img/pokemon.svg" class="w-24 group-hover:scale-110 transition-all ease-in-out">
            </a>

            <div class="w-auto flex gap-10 items-center">
                <a href="#" class="hover:text-white font-medium transition-all ease-in-out border-2 border-red-500 hover:bg-red-500 rounded-full py-1 px-3 bg-gradient-to-tl from-transparent to-transparent hover:from-rose-400 hover:to-red-500 hover:scale-110">Minha Pokedex</a>
                <a href="#" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Pokedex Completa</a>
                <a href="sobre.php" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Sobre nós</a>
                <a href="index.php" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Sair</a>

            </div>
        </header>
        <main class="flex-grow relative overflow-hidden flex flex-col">
            <section class="w-full flex flex-row px-10 pt-10 gap-10 relative justify-center items-center items-stretch">

                <div class="flex flex-row gap-3 px-2 rounded-full border-2 border-gray-300 text-gray-500 text-sm outline-none bg-white items-center">

                        <button class="rounded-full px-3 h-8 bg-gradient-to-tl from-rose-400 to-red-500 text-white font-bold hover:scale-110 transition-all ease-in-out hover:border-2 border-gray-400">Todos</button>
                        <button class="bg-gray-300 rounded-full px-3 h-8 font-bold hover:scale-110 transition-all ease-in-out hover:border-2 border-gray-400">Capturados</button>
                        <button class="bg-gray-300 rounded-full px-3 h-8 font-bold hover:scale-110 transition-all ease-in-out hover:border-2 border-gray-400">Pendentes</button>

                </div>

                <div class="flex flex-row gap-3 px-2 pl-0 rounded-full border-2 border-gray-300 text-gray-500 text-sm outline-none bg-white items-center">
                    <label for="gen" class="flex border-r-2 h-full items-center px-3 bg-gray-400 rounded-l-full">
                        <h1 class="font-[sans-serif] text-center text-white">Geração:</h1>
                    </label>
                    <div id="gen" class="flex flex-row gap-2 bg-white items-center" >
                        <button class="bg-gradient-to-tl from-rose-400 to-red-500 text-white rounded-full px-3 h-8 font-bold hover:scale-110 transition-all ease-in-out hover:border-2 border-gray-400">Todas</button>
                        <button class="bg-gray-300 rounded-full w-8 h-8 font-bold hover:scale-110 transition-all ease-in-out hover:border-2 border-gray-400">1</button>
                        <button class="bg-gray-300 rounded-full w-8 h-8 font-bold hover:scale-110 transition-all ease-in-out hover:border-2 border-gray-400">2</button>
                        <button class="bg-gray-300 rounded-full w-8 h-8 font-bold hover:scale-110 transition-all ease-in-out hover:border-2 border-gray-400">3</button>
                        <button class="bg-gray-300 rounded-full w-8 h-8 font-bold hover:scale-110 transition-all ease-in-out hover:border-2 border-gray-400">4</button>
                    </div>
                </div>
            <!--     Seleção de Geração       -->

 <!--               <div class="relative font-[sans-serif] w-max">
                    <button type="button" id="dropdownToggle"
                            class="rounded-full px-5 py-3 border-2 border-gray-300 text-gray-500 text-sm outline-none bg-white hover:bg-gray-50">
                        Geração
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-3 fill-gray-400 inline ml-3" viewBox="0 0 24 24">
                            <path fill-rule="evenodd"
                                  d="M11.99997 18.1669a2.38 2.38 0 0 1-1.68266-.69733l-9.52-9.52a2.38 2.38 0 1 1 3.36532-3.36532l7.83734 7.83734 7.83734-7.83734a2.38 2.38 0 1 1 3.36532 3.36532l-9.52 9.52a2.38 2.38 0 0 1-1.68266.69734z"
                                  clip-rule="evenodd" data-original="#000000" />
                        </svg>
                    </button>


                    <ul id="dropdownMenu" class=' text-center rounded-b-2xl absolute hidden shadow-2xl bg-white py-2 z-[1000] min-w-full w-max divide-y max-h-96 overflow-auto'>
                        <li class='py-3 px-5 hover:bg-gray-50 text-gray-800 text-sm cursor-pointer'>Gen 1</li>
                        <li class='py-3 px-5 hover:bg-gray-50 text-gray-800 text-sm cursor-pointer'>Gen 2</li>
                        <li class='py-3 px-5 hover:bg-gray-50 text-gray-800 text-sm cursor-pointer'>Gen 3</li>
                    </ul>
                </div>
-->
            <!--       Barra de pesquisa         -->

                <div class="flex rounded-full w-[50%] border-2 border-gray-300 overflow-hidden max-w-md font-[sans-serif]">
                    <input type="email" placeholder="Procurar pokemon..."
                           class="w-full outline-none bg-white text-gray-600 text-sm px-4 py-3" />
                    <button type='button' class="flex items-center justify-center bg-gray-400 px-5">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192.904 192.904" width="16px" class="fill-white">
                            <path
                                    d="m190.707 180.101-47.078-47.077c11.702-14.072 18.752-32.142 18.752-51.831C162.381 36.423 125.959 0 81.191 0 36.422 0 0 36.423 0 81.193c0 44.767 36.422 81.187 81.191 81.187 19.688 0 37.759-7.049 51.831-18.751l47.079 47.078a7.474 7.474 0 0 0 5.303 2.197 7.498 7.498 0 0 0 5.303-12.803zM15 81.193C15 44.694 44.693 15 81.191 15c36.497 0 66.189 29.694 66.189 66.193 0 36.496-29.692 66.187-66.189 66.187C44.693 147.38 15 117.689 15 81.193z">
                            </path>
                        </svg>
                    </button>
                </div>
            </section>

            <!-- Cards Pokemon -->

            <div class="w-full p-8 z-10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 justify-around gap-8 grid-flow-row auto-rows-max ">
                <?php
                // Define the background colors for each type
                $typeColors = [
                    1 => 'bg-gradient-to-r from-lime-400 to-lime-500',
                    2 => 'bg-gradient-to-r from-fuchsia-600  to-purple-600',
                    3 => 'bg-green-500',
                    4 => 'bg-yellow-500',
                    // Add more types as needed...
                ];

                while ($row = pg_fetch_assoc($result)):
                    // Get colors based on the type IDs
                    $type1Color = $typeColors[$row['pokedex_tipo_1']] ?? 'bg-gray-400'; // Default color if type not found
                    $type2Color = $row['pokedex_tipo_2'] ? ($typeColors[$row['pokedex_tipo_2']] ?? 'bg-gray-400') : null;
                    ?>
                    <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-gradient-to-tr to-lime-300/35 from-emerald-400 text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                        <section class="flex flex-col z-10 flex-start">
                            <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#<?php echo str_pad($row['pokedex_num'], 3, '0', STR_PAD_LEFT); ?></h1>
                            <h1 class="text-center text-xl font-bold my-3"><?php echo htmlspecialchars($row['pokedex_nome']); ?></h1>
                            <div class="flex flex-col gap-2">
                                <p class="py-0.5 px-6
                                <?php echo $type1Color; ?> backdrop-blur-sm w-auto rounded-full text-center shadow-md">
                                    <?php echo htmlspecialchars($row['type1_name']); ?>
                                </p>
                                <?php if (!empty($row['type2_name'])): ?>
                                    <p class="py-0.5 px-6 <?php echo $type2Color; ?> rounded-full text-center shadow-md"><?php echo htmlspecialchars($row['type2_name']); ?></p>
                                <?php endif; ?>
                            </div>
                        </section>
                        <img src="https://archives.bulbagarden.net/media/upload/thumb/f/fb/0001Bulbasaur.png/375px-0001Bulbasaur.png" class="relative w-40 z-10 self-end">
                        <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                    </div>
                <?php endwhile; ?>
<!--
                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-gradient-to-tr to-lime-300/35 from-emerald-400 text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 flex-start">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#002</h1>
                        <h1 class="text-center text-xl font-bold my-3">Ivysaur</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-lime-400 to-lime-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Plant</p>
                            <p class="py-0.5 px-6 bg-gradient-to-r from-fuchsia-600 w-auto to-purple-600 rounded-full text-center shadow-md">Poison</p>
                        </div>
                    </section>
                    <img src="img/png/002.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>

                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-gradient-to-tr to-lime-300/35 from-emerald-400 text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 flex-start">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#003</h1>
                        <h1 class="text-center text-xl font-bold my-3">Venusaur</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-lime-400 to-lime-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Plant</p>
                            <p class="py-0.5 px-6 bg-gradient-to-r from-fuchsia-600 w-auto to-purple-600 rounded-full text-center shadow-md">Poison</p>
                        </div>
                    </section>
                    <img src="img/png/003.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>

                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-fire text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 flex-start">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#004</h1>
                        <h1 class="text-center text-xl font-bold my-3">Charmander</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-red-400 to-orange-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Fire</p>
                        </div>
                    </section>
                    <img src="img/png/004.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>

                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-fire text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 flex-start">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#005</h1>
                        <h1 class="text-center text-xl font-bold my-3">Charmeleon</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-red-400 to-orange-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Fire</p>

                        </div>
                    </section>
                    <img src="img/png/005.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>

                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-fire text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 flex-start">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#006</h1>
                        <h1 class="text-center text-xl font-bold my-3">Charizard</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-red-400 to-orange-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Fire</p>

                        </div>
                    </section>
                    <img src="img/png/006.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>

                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-water text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 top-0 ">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#007</h1>
                        <h1 class="text-center text-xl font-bold my-3">Squirtle</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-sky-400 to-cyan-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Water</p>
                        </div>
                    </section>
                    <img src="img/png/007.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>

                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-water text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 top-0 ">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#008</h1>
                        <h1 class="text-center text-xl font-bold my-3">Wartotle</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-sky-400 to-cyan-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Water</p>
                        </div>
                    </section>
                    <img src="img/png/008.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>

                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-water text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 top-0 ">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#009</h1>
                        <h1 class="text-center text-xl font-bold my-3">Blastoise</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-sky-400 to-cyan-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Water</p>
                        </div>
                    </section>
                    <img src="img/png/009.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>

                <div onclick="showModal()" class="flex-1 justify-around group px-0 py-6 bg-gradient-to-tr to-lime-300/35 from-emerald-400 text-white hover:scale-105 transition-all ease-in-out rounded-2xl flex flex-row relative overflow-hidden hover:cursor-pointer hover:shadow-2xl">
                    <section class="flex flex-col z-10 flex-start">
                        <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 border-white rounded-full opacity-85">#010</h1>
                        <h1 class="text-center text-xl font-bold my-3">Caterpie</h1>
                        <div class="flex flex-col gap-2">
                            <p class="py-0.5 px-6 bg-gradient-to-r from-lime-400 to-lime-500 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Bug</p>
                        </div>
                    </section>
                    <img src="img/png/010.png" class="relative w-36 z-10 self-end">
                    <img src="img/pb-white.svg" class="absolute w-60 z-0 -right-20 -bottom-20 opacity-50 group-hover:rotate-180 group-hover:scale-110 duration-300">
                </div>
-->
            </div>
<!--Modal-->
            <!-- Modal Background Blur -->
            <div id="blurBackground" class="blur-background"></div>

            <!-- Modal -->
            <div id="modal" class="fixed inset-0 flex-col gap-5 flex items-center justify-center hidden z-20 transition-opacity duration-300 ease-in-out opacity-0">
                <div class="relative bg-white relative rounded-2xl overflow-hidden shadow-lg max-w-sm w-full transition-opacity duration-300 ease-in-out opacity-0" id="modalContent">
                    <div class="relative overflow-hidden bg-emerald-500 pt-5 pb-1 bg-emerald-500 rounded-2xl flex-start px-5">
                        <div class="z-40 flex flex-row justify-between items-center p-0">
                            <h1 class="text-[2rem] text-white font-bold">Bulbasaur</h1>
                            <h1 class="text-left text-2xl font-bold py-0.5 px-6 border-4 text-white border-white rounded-full opacity-85">#001</h1>
                        </div>  
                        <div class="z-40 w-full h-[1px] my-3" style="background-image: linear-gradient(90deg, rgba(255, 255, 255, 0) 1.46%, rgba(255, 255, 255, 0.6) 40.83%, rgba(255, 255, 255, 0.3) 65.57%, rgba(255, 255, 255, 0) 107.92%);"></div>
                        <div class="z-40 flex flex-row gap-2 justify-start text-white">
                            <p class="flex-1 py-0.5 px-2 bg-gradient-to-r from-lime-400 to-lime-500 max-w-20 backdrop-blur-sm w-auto rounded-full text-center shadow-md">Plant</p>
                            <p class="flex-1 py-0.5 px-2 bg-gradient-to-r from-fuchsia-600 max-w-20 to-purple-600 rounded-full text-center shadow-md">Poison</p>
                        </div>
                        <div class="z-40">
                            <img src="https://archives.bulbagarden.net/media/upload/thumb/f/fb/0001Bulbasaur.png/375px-0001Bulbasaur.png" class="w-60 justify-self-center z-30" alt="">
                        </div>
                    </div>
                    <div class="bg-white px-8 py-4">
                        <div class="flex justify-around mb-4 text-gray-500">
                            <button onclick="showContent('content1')" class="tab-button text-blue-500 font-bold border-b-2 border-blue-500 pb-2">Tab 1</button>
                            <button onclick="showContent('content2')" class="tab-button font-bold hover:text-blue-500 pb-2">Tab 2</button>
                            <button onclick="showContent('content3')" class="tab-button font-bold hover:text-blue-500 pb-2">Tab 3</button>
                        </div>

                        <!-- Tab Content -->
                        <div class="mt-4 text-gray-500 flex justify-center">
                            <div id="content1" class="tab-content active">
                                <h2 class="text-lg font-bold">Teste menu 1</h2>

                            </div>
                            <div id="content2" class="tab-content">
                                <h2 class="text-lg font-bold">Teste menu 2</h2>
                            </div>
                            <div id="content3" class="tab-content">
                                <h2 class="text-lg font-bold">Teste menu 3</h2>
                            </div>
                        </div>
                    </div>
                </div>
                <button onclick="hideModal()" type="submit" class="group w-32 relative items-center flex flex-row transition-all ease-in-out justify-self-center text-white hover:duration-300 border-2 border-gray-300 hover:border-gray-950 bg-gradient-to-tl from-gray-500 to-gray-700 hover:from-rose-400 hover:to-red-500 focus:ring-4 focus:outline-none font-medium rounded-3xl text-sm px-2 py-2.5 text-center">
                    <img src="img/pb-white.svg" class="absolute w-6 group-hover:rotate-180 group-hover:scale-125 duration-300">
                    <span class="flex-1 text-center">Fechar</span>
                </button>
            </div>

            <img src="img/pb-black.svg" class="absolute w-[25%] z-0 opacity-15 duration-300 -right-20 -bottom-40 animate-slow-spin">
        </main>

<!--        -->
    <footer class="flex flex-row justify-center bg-white text-center p-3 border-t border-gray-400 text-slate-650">
        © Ciência da Computação - UFERSA 2024.1 | <p class="text-red-600 mx-2"> PokedexBD </p> | Todos os direitos reservados.
    </footer>
    <script src="script.js"></script>
    <script src="menu.js"></script>
    
</body>
</html>