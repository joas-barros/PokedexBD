document.addEventListener("DOMContentLoaded", () => {
    const registerForm = document.getElementById("register-form");
    const modal = document.getElementById("modal");
    const modalBg = document.getElementById("modal-bg");
    const modalContent = modal.querySelector("div.bg-white");
    const closeModalBtn = document.getElementById("close-modal");

    // Check if registration was successful
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('success')) {
        showModal();
    }

    closeModalBtn.addEventListener("click", hideModal);
    modalBg.addEventListener("click", hideModal);

    function showModal() {
        modalBg.style.display = 'block';
        modal.classList.remove('hidden');

        setTimeout(() => {
            modalContent.classList.remove('opacity-0');
            modalContent.classList.add('opacity-100', 'scale-100');
        }, 10);
    }

    function hideModal() {
        modalContent.classList.remove('opacity-100', 'scale-100');
        modalContent.classList.add('opacity-0', 'scale-75');

        setTimeout(() => {
            modal.classList.add('hidden');
            modalBg.style.display = 'none';
        }, 300);
    }
});
