let dropdownToggle = document.getElementById('dropdownToggle');
let dropdownMenu = document.getElementById('dropdownMenu');

function handleClick() {
    if (dropdownMenu.className.includes('block')) {
        dropdownMenu.classList.add('hidden')
        dropdownMenu.classList.remove('block')
    } else {
        dropdownMenu.classList.add('block')
        dropdownMenu.classList.remove('hidden')
    }
}
dropdownToggle.addEventListener('click', handleClick);


// Modal ---------------------------------------------------------------------------------------------

function showModal() {
    const modal = document.getElementById('modal');
    const modalContent = document.getElementById('modalContent');
    const blurBackground = document.getElementById('blurBackground');

    blurBackground.style.display = 'block'; // Show the blur background
    blurBackground.classList.add('backdrop-blur'); // Apply blur effect

    modal.classList.remove('hidden');
    setTimeout(() => {
        modal.classList.remove('opacity-0');
        modal.classList.add('opacity-100');
        modalContent.classList.remove('opacity-0');
        modalContent.classList.add('opacity-100');
    }, 10); // Delay for transition
}

function hideModal() {
    const modal = document.getElementById('modal');
    const modalContent = document.getElementById('modalContent');
    const blurBackground = document.getElementById('blurBackground');

    modal.classList.remove('opacity-100');
    modal.classList.add('opacity-0');
    modalContent.classList.remove('opacity-100');
    modalContent.classList.add('opacity-0');

    // Remove blur background after modal transition
    setTimeout(() => {
        modal.classList.add('hidden');
        blurBackground.style.display = 'none'; // Hide blur background
        blurBackground.classList.remove('backdrop-blur'); // Remove blur effect
    }, 300); // Delay to match transition duration
}

function showContent(contentId) {
    const contents = document.querySelectorAll('.tab-content');
    const buttons = document.querySelectorAll('.tab-button');

    // Hide all contents and remove active styles from buttons
    contents.forEach(content => {
        content.classList.remove('active');
    });
    buttons.forEach(button => {
        button.classList.remove('border-b-2', 'border-blue-500', 'text-blue-500');
        button.classList.add('hover:text-blue-500');
    });

    // Show selected content and apply active styles to the button
    document.getElementById(contentId).classList.add('active');
    const activeButton = Array.from(buttons).find(button => button.textContent.includes(contentId.replace('content', 'Tab ')));
    activeButton.classList.add('border-b-2', 'border-blue-500', 'text-blue-500');
}
