

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>
    <link rel="stylesheet" href="output.css">
    <link rel="stylesheet" href="input.css">
    <link rel="icon" href="img/pb-icon.svg">
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css"  rel="stylesheet" />

</head>
<body class="flex flex-col min-h-screen w-screen bg-white max-w-full">
<header class="w-full h-14 flex flex-row items-center justify-between px-10 py-3 border-b border-gray-300">
    <a href="dashboard.php" class="group">
        <img src="img/pokemon.svg" class="w-24 group-hover:scale-110 transition-all ease-in-out">
    </a>

    <div class="w-auto flex gap-10 items-center">
        <a href="#" class="hover:text-white font-medium transition-all ease-in-out border-2 border-red-500 hover:bg-red-500 rounded-full py-1 px-3 bg-gradient-to-tl from-transparent to-transparent hover:from-rose-400 hover:to-red-500 hover:scale-110">Administrador</a>
        <a href="dashboard.php" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Pokedex Completa</a>
        <a href="#" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Sobre nós</a>
        <a href="index.php" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Sair</a>

    </div>
</header>
<main class="flex-grow relative overflow-hidden flex p-8">
    <div data-modal-target="default-modal" data-modal-toggle="default-modal" class="w-full p-8 z-10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 justify-around gap-5 grid-flow-row auto-rows-max  bg-gray-100 justify-center rounded-2xl h-full overflow-hidden">
        <section class="bg-white rounded-xl flex flex-1  max-w-80 flex-row overflow-hidden hover:scale-[1.02] min-w-80 transition-all ease-in-out hover:cursor-pointer">
            <div class="w-2 h-full bg-red-500"></div>
            <div class="p-3 justify-center flex flex-col text-center w-full">
                <h1 class="text-gray-500 text-bold w-full">Treinadores Cadastrados</h1>
                <div class="p-5">3</div>
            </div>
        </section>
    </div>

    <div id="default-modal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative p-4 w-full max-w-2xl max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        Terms of Service
                    </h3>
                    <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="default-modal">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <div class="p-4 md:p-5 space-y-4">
                    <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                        With less than a month to go before the European Union enacts new consumer privacy laws for its citizens, companies around the world are updating their terms of service agreements to comply.
                    </p>
                    <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                        The European Union’s General Data Protection Regulation (G.D.P.R.) goes into effect on May 25 and is meant to ensure a common set of data rights in the European Union. It requires organizations to notify users as soon as possible of high-risk data breaches that could personally affect them.
                    </p>
                </div>
                <!-- Modal footer -->
                <div class="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                    <button data-modal-hide="default-modal" type="button" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">I accept</button>
                    <button data-modal-hide="default-modal" type="button" class="py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">Decline</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Background Blur -->
    <!-- Modal -->







    <img src="img/pb-black.svg" class="absolute w-[25%] z-0 opacity-15 duration-300 -right-20 -bottom-40 animate-slow-spin">
</main>

<!--        -->
<footer class="flex flex-row justify-center bg-white text-center p-3 border-t border-gray-400 text-slate-650">
    © Ciência da Computação - UFERSA 2024.1 | <p class="text-red-600 mx-2"> PokedexBD </p> | Todos os direitos reservados.
</footer>
<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
<script src="script.js"></script>
</body>
</html>