<?php
$host = "localhost";
$port = "5432";
$dbname = "pokedexbd";
$user = "postgres";
$password = "root";
$connection_string = "host={$host} port={$port} dbname={$dbname} user={$user} password={$password} ";
$dbconn = pg_connect($connection_string);
if(isset($_POST['submit'])&&!empty($_POST['submit'])){

    $sql = "INSERT INTO public.treinador(treinador_nome, treinador_email, treinador_senha, treinador_data_nascimento)VALUES('".$_POST['treinador_nome']."','".$_POST['treinador_email']."','".md5($_POST['treinador_senha'])."','".$_POST['treinador_data_nascimento']."')";
    $ret = pg_query($dbconn, $sql);
    if($ret){
        header("Location: register.php?success=1");
        exit();
    }else{

        echo "Algo deu errado";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PokedexBD</title>
    <link rel="stylesheet" href="output.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="img/pb-icon.svg">
    <script src=
                    "https://cdn.tailwindcss.com">
    </script>
</head>
<body class="bg-reg-bg bg-cover">
<footer class="w-screen h-screen flex flex-col justify-center items-center mt-[-30px]">
    <a class="w-64 mb-3">
        <img src="img/pokemon.svg">
    </a>
    <div class="w-10/12 backdrop-blur-sm bg-white/75 grid rounded-2xl shadow-2xl md:mt-0 sm:max-w-md xl:p-0">

        <div class="p-6 grid space-y-4 md:space-y-4 sm:p-8">
            <h1 class="font-sans text-xl justify-self-center leading-tight font-regular tracking-tight text-gray-500 md:text-2xl">
                Registre-se agora!
            </h1>
            <div class="w-full h-[1px] my-3 lg:mb-10" style="background-image: linear-gradient(90deg, rgba(149, 131, 198, 0) 1.46%, rgba(149, 131, 198, 0.6) 40.83%, rgba(149, 131, 198, 0.3) 65.57%, rgba(149, 131, 198, 0) 107.92%);"></div>
            <form method="POST" class="flex flex-col grid space-y-4 md:space-y-4" autocomplete="off">
                <div class="flex flex-cols gap-5">
                    <div>
                        <label for="treinador_nome" class="block mb-2  mx-2 text-sm font-medium text-gray-500">Treinador</label>
                        <input type="text" name="treinador_nome" id="treinador_nome" class="bg-gray-50 border-2 border-gray-400 text-gray-900 rounded-full focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="Treinador..." required="">
                    </div>
                    <div>
                        <label for="treinador_data_nascimento" class="block mb-2  mx-2 text-sm font-medium text-gray-500">Data de nascimento</label>
                        <input type="date" name="treinador_data_nascimento" id="treinador_data_nascimento" class="appearance-none bg-gray-50 slate-400 border-2 border-gray-400 text-gray-900 rounded-full focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="teste" required="">
                    </div>
                </div>
                <div>
                    <label for="treinador_email" class="block mb-2  mx-2 text-sm font-medium text-gray-500">Email</label>
                    <input type="email" name="treinador_email" id="treinador_email" class="bg-gray-50 border-2 border-gray-400 text-gray-900 rounded-full focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="email@companhia.com" required="">
                </div>
                <div class="flex flex-cols gap-5">
                    <div class="mb-4 relative">
                        <label for="password" class="block mb-2 mx-2 text-sm font-medium text-gray-500">Senha</label>
                        <div class="flex items-center">
                            <input type="password" name="treinador_senha" id="password" placeholder="••••••••" required class="bg-gray-50 border-2 border-gray-400 text-gray-900 rounded-full focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5">
                            <button type="button" id="togglePassword"
                                    class="focus:outline-none -ml-8">
                                <img src="https://media.geeksforgeeks.org/wp-content/uploads/20240227164304/visible.png" alt="" class="w-4 hover:scale-125">
                            </button>
                        </div>
                    </div>

                    <div class="mb-4 relative">
                        <label for="password1" class="block mb-2 mx-2 text-sm font-medium text-gray-500">Confirmar senha</label>
                        <div class="flex items-center">
                            <input type="password" id="password1" name="treinador_senha" placeholder="••••••••" required  class="bg-gray-50 border-2 border-gray-400 text-gray-900 rounded-full focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5">
                            <button type="button" id="togglePassword1"
                                    class="focus:outline-none -ml-8">
                                <img src="https://media.geeksforgeeks.org/wp-content/uploads/20240227164304/visible.png" alt="" class="w-4 hover:scale-125">
                            </button>
                        </div>
                    </div>
                </div>

                <button type="submit" name="submit" value="submit" class="group w-36 relative items-center flex flex-row transition-all ease-in-out justify-self-center text-white hover:duration-500 border-2 border-gray-300 hover:border-gray-950 bg-gradient-to-tl from-gray-500 to-gray-700 hover:from-rose-400 hover:to-red-500 focus:ring-4 focus:outline-none font-medium rounded-3xl text-sm px-2 py-2.5 text-center">
                    <img src="img/pb-white.svg" class="absolute w-6 group-hover:rotate-180 group-hover:scale-125 duration-300">
                    <span class="flex-1 text-center">Registrar</span>
                </button>
            </form>
            <div class="w-full h-[1px] my-3 lg:mb-10" style="background-image: linear-gradient(90deg, rgba(149, 131, 198, 0) 1.46%, rgba(149, 131, 198, 0.6) 40.83%, rgba(149, 131, 198, 0.3) 65.57%, rgba(149, 131, 198, 0) 107.92%);"></div>
            <p class="text-sm font-regular text-gray-600 justify-self-center">
                Já tem uma conta? <a href="index.php" class="font-medium text-primary-600 hover:underline">Entre agora!</a>
            </p>
        </div>
    </div>

    <!-- Modal -->
    <div id="modal" class="fixed inset-0 flex items-center justify-center z-50 hidden">
        <div id="modal-bg" class="fixed inset-0 bg-black bg-opacity-50 blur-bg"></div>
        <div class="relative text-gray-700 overflow-hidden bg-white rounded-2xl shadow-2xl p-6 transform transition-transform duration-300 scale-75 opacity-0">
            <h2 class="text-2xl font-bold text-gray-500">Sucesso!</h2>
            <div class="w-full h-[1px] my-3 lg:mb-3" style="background-image: linear-gradient(90deg, rgba(149, 131, 198, 0) 1.46%, rgba(149, 131, 198, 0.6) 40.83%, rgba(149, 131, 198, 0.3) 65.57%, rgba(149, 131, 198, 0) 107.92%);"></div>
            <div class="py-3 text-center">
                <p>Você foi registrado com sucesso!</p>
                <p>Prossiga para a tela de login.</p>
            </div>
            <div class="w-full h-[1px] my-3 lg:mb-3" style="background-image: linear-gradient(90deg, rgba(149, 131, 198, 0) 1.46%, rgba(149, 131, 198, 0.6) 40.83%, rgba(149, 131, 198, 0.3) 65.57%, rgba(149, 131, 198, 0) 107.92%);"></div>
            <form action="index.php">
                <button type="submit" class="group w-32 relative items-center flex flex-row transition-all ease-in-out justify-self-center text-white hover:duration-300 border-2 border-gray-300 hover:border-gray-950 bg-gradient-to-tl from-gray-500 to-gray-700 hover:from-rose-400 hover:to-red-500 focus:ring-4 focus:outline-none font-medium rounded-3xl text-sm px-2 py-2.5 text-center">
                    <img src="img/pb-white.svg" class="absolute w-6 group-hover:rotate-180 group-hover:scale-125 duration-300">
                    <span class="flex-1 text-center">Login</span>
                </button>
            </form>

            <img src="img/pb-black.svg" class="absolute w-[42%] z-0 opacity-15 -left-12 -bottom-12 animate-medium-spin">
            <img src="img/pb-black.svg" class="absolute w-[42%] z-0 opacity-15 -right-12 -top-12 animate-medium-spin">
        </div>
    </div>

    <footer class="shadow absolute inset-x-0 bottom-0 text-center p-3 bg-gradient-to-t from-slate-950 to-transparent text-white opacity-75">
        © Ciência da Computação - UFERSA 2024.1 | PokedexBD | Todos os direitos reservados.</footer>
</footer>

<script src="toggle.js"></script>
<script src="success.js"></script>
</body>
</html>