function showContent(contentId) {
    const contents = document.querySelectorAll('.tab-content');
    const buttons = document.querySelectorAll('.tab-button');

    // Hide all contents and remove active styles from buttons
    contents.forEach(content => {
        content.classList.remove('active');
    });
    buttons.forEach(button => {
        button.classList.remove('border-b-2', 'border-blue-500', 'text-blue-500');
        button.classList.add('hover:text-blue-500');
    });

    // Show selected content and apply active styles to the button
    document.getElementById(contentId).classList.add('active');
    const activeButton = Array.from(buttons).find(button => button.textContent.includes(contentId.replace('content', 'Tab ')));
    activeButton.classList.add('border-b-2', 'border-blue-500', 'text-blue-500');
}