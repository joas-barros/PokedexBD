<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>
    <link rel="stylesheet" href="./output.css">
    <link rel="stylesheet" href="./input.css">
    <link rel="icon" href="img/pb-icon.svg">

</head>
<body class="flex flex-col min-h-screen w-screen bg-white max-w-full">
<header class="w-full h-14 flex flex-row items-center justify-between px-10 py-3 border-b border-gray-300">
    <a href="dashboard.php" class="group">
        <img src="img/pokemon.svg" class="w-24 group-hover:scale-110 transition-all ease-in-out">
    </a>

    <div class="w-auto flex gap-10 items-center">
        <a href="#" class="hover:text-white font-medium transition-all ease-in-out border-2 border-red-500 hover:bg-red-500 rounded-full py-1 px-3 bg-gradient-to-tl from-transparent to-transparent hover:from-rose-400 hover:to-red-500 hover:scale-110">Minha Pokedex</a>
        <a href="#" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Pokedex Completa</a>
        <a href="#" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Sobre nós</a>
        <a href="index.php" class="hover:text-red-500 transition-all ease-in-out hover:scale-110">Sair</a>

    </div>
</header>
<main class="mb-auto relative overflow-hidden flex p-10 justify-center">
    <section class="p-8 bg-ghostpkm rounded-2xl border-2 border-gray-300 bg-cover">
        <div class="flex flex-col p-8 bg-white/50 backdrop-blur rounded-2xl items-center gap-5">
            <div class="p-2 bg-white border-4 border-fuchsia-800 rounded-full">
                <img src="img/creators/guilherme.png" alt="" class="rounded-full w-40">
            </div>
            <div class="text-white bg-gradient-to-trs from-fuchsia-800 to-violet-900 rounded-full py-2 px-5">
                <h1>glhermeMelo</h1>
            </div>
            <img src="img/creators/ghost-badge.png" alt="" class="w-16">
        </div>

    </section>
</main>

<!--        -->
<footer class="flex flex-row justify-center bg-white text-center p-3 border-t border-gray-400 text-slate-650">
    © Ciência da Computação - UFERSA 2024.1 | <p class="text-red-600 mx-2"> PokedexBD </p> | Todos os direitos reservados.
</footer>
<script src="script.js"></script>
</body>
</html>